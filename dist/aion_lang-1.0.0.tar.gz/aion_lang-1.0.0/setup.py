# =============================================================
# AION Language — PyPI Package Setup
# =============================================================

from setuptools import setup

if __name__ == "__main__":
    setup()